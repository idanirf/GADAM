package com.dam.gestionalmacendam.repositories.Order;

import com.dam.gestionalmacendam.models.Order;
import com.dam.gestionalmacendam.repositories.CRUDRepository;

public interface ICRUDOrder extends CRUDRepository<Order, String> {
}
