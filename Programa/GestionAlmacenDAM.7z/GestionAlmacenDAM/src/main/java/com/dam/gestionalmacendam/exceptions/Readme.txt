Cuando se añada algo eliminar este archivo.
