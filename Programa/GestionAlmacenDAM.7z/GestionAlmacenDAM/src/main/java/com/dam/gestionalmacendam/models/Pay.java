package com.dam.gestionalmacendam.models;

public enum Pay {
    PAYPAL, CARD
}
